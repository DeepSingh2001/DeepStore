<html><body>
    <?php
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];
    //database connection
    $conn = new mysqli('localhost', 'root', '', 'deepstore');
    if($conn->connect_error){
        die('connection failed:' .$conn->connection_error);
    } else {
        $stmt = $conn->prepare("insert into login(Username,Password)
            values(?, ?)");
        $stmt->bind_param("ss",$Username,$Password);
        $stmt->execute();
        echo "registration succesfully..";
        $stmt->close();
        $conn->close();
    }
?></body></html>